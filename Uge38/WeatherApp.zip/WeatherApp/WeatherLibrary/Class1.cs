﻿namespace WeatherLibrary
{
    public class Class1
    {

    }
}