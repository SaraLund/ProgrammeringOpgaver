﻿namespace WeatherLibrary
{
    public class Coord
    {
        public double lat { get; set; }
        public double lon { get; set; }
    }
}
