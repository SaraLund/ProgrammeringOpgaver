﻿namespace WeatherLibrary
{
    public class Cloud
    {
        public int all { get; set; }
    }
}
