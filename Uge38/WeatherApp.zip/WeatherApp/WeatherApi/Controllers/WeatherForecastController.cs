using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace WeatherApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public async IEnumerable<WeatherForecast> Get()
        {
            HttpClient client = new HttpClient();
            using HttpResponseMessage response = await client.GetAsync("https://api.openweathermap.org/data/2.5/weather?lat=55.0443&lon=9.4174&appid=fe5e02383d8389c0ed719c4281aa7994");

            response.EnsureSuccessStatusCode();

            var jsonResponse = await response.Content.ReadAsStringAsync();

            var weatherForecast =
               JsonSerializer.Deserialize<Root>(jsonResponse);

            return View(weatherForecast);
        }
    }
}